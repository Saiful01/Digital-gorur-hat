<!-- instagram section -->
<section class="instagram ratio_square">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 p-0">
                <h2 class="title-borderless"># instagram</h2>
                <div class="slide-7 no-arrow slick-instagram">
                    <div>
                        <a href="#">
                            <div class="instagram-box"><img src="/ecommerce/assets/images/slider/2.jpg" class="bg-img"
                                                            alt="Avatar" style="width:100%">
                                <div class="overlay"><i class="fa fa-instagram" aria-hidden="true"></i></div>
                            </div>
                        </a>
                    </div>
                    <div>
                        <a href="#">
                            <div class="instagram-box"><img src="/ecommerce/assets/images/slider/3.jpg" class="bg-img"
                                                            alt="Avatar" style="width:100%">
                                <div class="overlay"><i class="fa fa-instagram" aria-hidden="true"></i></div>
                            </div>
                        </a>
                    </div>
                    <div>
                        <a href="#">
                            <div class="instagram-box"><img src="/ecommerce/assets/images/slider/4.jpg" class="bg-img"
                                                            alt="Avatar" style="width:100%">
                                <div class="overlay"><i class="fa fa-instagram" aria-hidden="true"></i></div>
                            </div>
                        </a>
                    </div>
                    <div>
                        <a href="#">
                            <div class="instagram-box"><img src="/ecommerce/assets/images/slider/9.jpg" class="bg-img"
                                                            alt="Avatar" style="width:100%">
                                <div class="overlay"><i class="fa fa-instagram" aria-hidden="true"></i></div>
                            </div>
                        </a>
                    </div>
                    <div>
                        <a href="#">
                            <div class="instagram-box"><img src="/ecommerce/assets/images/slider/6.jpg" class="bg-img"
                                                            alt="Avatar" style="width:100%">
                                <div class="overlay"><i class="fa fa-instagram" aria-hidden="true"></i></div>
                            </div>
                        </a>
                    </div>
                    <div>
                        <a href="#">
                            <div class="instagram-box"><img src="/ecommerce/assets/images/slider/7.jpg" class="bg-img"
                                                            alt="Avatar" style="width:100%">
                                <div class="overlay"><i class="fa fa-instagram" aria-hidden="true"></i></div>
                            </div>
                        </a>
                    </div>
                    <div>
                        <a href="#">
                            <div class="instagram-box"><img src="/ecommerce/assets/images/slider/8.jpg" class="bg-img"
                                                            alt="Avatar" style="width:100%">
                                <div class="overlay"><i class="fa fa-instagram" aria-hidden="true"></i></div>
                            </div>
                        </a>
                    </div>
                    <div>
                        <a href="#">
                            <div class="instagram-box"><img src="/ecommerce/assets/images/slider/9.jpg" class="bg-img"
                                                            alt="Avatar" style="width:100%">
                                <div class="overlay"><i class="fa fa-instagram" aria-hidden="true"></i></div>
                            </div>
                        </a>
                    </div>
                    <div>
                        <a href="#">
                            <div class="instagram-box"><img src="/ecommerce/assets/images/slider/2.jpg" class="bg-img"
                                                            alt="Avatar" style="width:100%">
                                <div class="overlay"><i class="fa fa-instagram" aria-hidden="true"></i></div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- instagram section end -->
