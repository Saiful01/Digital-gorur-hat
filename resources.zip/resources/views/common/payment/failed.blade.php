@extends('layouts.common')
@section('title', 'Cart')

@section('content')
    <section class="section-b-space light-layout">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="text-info success-text"><i class="fa fa-warning text-danger" aria-hidden="true"></i>
                        {{--   <h2></h2>--}}
                        <p>Payment attempt failed</p>
                    {{--    <a href="#">Retry</a>--}}
                    </div>
                </div>
            </div>
        </div>
    </section>

@stop