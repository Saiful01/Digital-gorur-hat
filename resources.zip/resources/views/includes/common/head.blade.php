<title>Gorur hat: @yield('title')</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="multikart">
<meta name="keywords" content="multikart">
<meta name="author" content="multikart">
<link rel="icon" href="/ecommerce/assets/images/icon/logo.png" type="image/x-icon">
<link rel="shortcut icon" href="/ecommerce/assets/images/icon/logo.png" type="image/x-icon">

<!--Google font-->
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">

<!-- Icons -->
<!--    <link rel="stylesheet" type="text/css" href="/ecommerce/assets/css/fontawesome.css">-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!--Slick slider css-->
<link rel="stylesheet" type="text/css" href="/ecommerce/assets/css/slick.css">
<link rel="stylesheet" type="text/css" href="/ecommerce/assets/css/slick-theme.css">

<!-- Animate icon -->
<link rel="stylesheet" type="text/css" href="/ecommerce/assets/css/animate.css">

<!-- Themify icon -->
<link rel="stylesheet" type="text/css" href="/ecommerce/assets/css/themify-icons.css">

<!-- Bootstrap css -->
<link rel="stylesheet" type="text/css" href="/ecommerce/assets/css/bootstrap.css">

<!-- Theme css -->
<link rel="stylesheet" type="text/css" href="/ecommerce/assets/css/color1.css" media="screen" id="color">
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>

<!--Toaster-->
<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>


<script src="/js/cart.js"></script>

<style>
    .home-slider .slider-contain h1, .center-slider .slider-contain h1 {
        margin-bottom: 0;
        margin-top: 10px;
        color: #ffffff;
    }

    html {
        scroll-behavior: smooth;
    }
</style>
