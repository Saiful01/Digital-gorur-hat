<title>Admin @yield('title')</title>
<meta charset="utf-8" />




<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
<meta content="Themesbrand" name="author" />
<!-- App favicon -->
<link rel="shortcut icon" href="{{asset('assets/images/favicon.ico')}}">

<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>


<link href="{{asset('assets/libs/chartist/chartist.min.css')}}" rel="stylesheet">
<link href="{{asset('css/custom.css')}}" rel="stylesheet">


<!-- Bootstrap Css -->
<link href="{{asset('assets/css/bootstrap.min.css')}}" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="{{asset('assets/css/icons.min.css')}}" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="{{asset('assets/css/app.min.css')}}" id="app-style" rel="stylesheet" type="text/css" />




<link href="/assets/libs/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">

<!-- DataTables -->
<link href="/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="/assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />

<!-- Responsive datatable examples -->
<link href="/assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />



<meta charset="UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="pingback" href="https://joldi.com.bd/xmlrpc.php"/>


    <title>Joldi Courier |</title>
    <link rel='dns-prefetch' href='//fonts.googleapis.com'/>
    <link rel='dns-prefetch' href='//s.w.org'/>


    <meta content="Divi Child v.1.0" name="generator"/>
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <script src="/js/jquery.min.js"></script>
    <script src="/js/popper.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <link rel='stylesheet' id='ags-divi-icons-css' href='/css/icons.css' type='text/css' media='all'/>
    <link rel='stylesheet' id='wp-block-library-css' href='/css/style.min.css' type='text/css' media='all'/>
    <link rel='stylesheet' id='divi-fonts-css' href='/css/family.css' type='text/css' media='all'/>
    <link rel='stylesheet' id='divi-style-css' href='/css/content.css' type='text/css' media='all'/>
    <link rel='stylesheet' id='et-builder-googlefonts-cached-css' href='/css/latin.css' type='text/css' media='all'/>
    <link rel='stylesheet' id='dashicons-css' href='/css/dashicons.min.css' type='text/css' media='all'/>
    <script type='text/javascript' src='/js/jquery.js'></script>
    <script type='text/javascript' src='/js/jquery-migrate.min.js'></script>

    <script type='text/javascript' src='/js/icons.js'></script>
    <link rel='https://api.w.org/' href='https://joldi.com.bd/wp-json/'/>
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://joldi.com.bd/xmlrpc.php?rsd"/>
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://joldi.com.bd/wp-includes/wlwmanifest.xml"/>

    <link rel="stylesheet" id="et-core-unified-cached-inline-styles" href="/css/unified.min.css"/>

