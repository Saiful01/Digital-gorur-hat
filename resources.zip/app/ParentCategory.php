<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ParentCategory extends Model
{
    public $timestamps=true;
    protected $guarded=[];
}
